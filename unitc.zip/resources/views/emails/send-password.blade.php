<!DOCTYPE html>
<html>
<head>
    <title>Your Login Credentials</title>
</head>
{{-- <body>
    <p>Dear {{ $name }},</p>
    <p>Welcome to our platform! You have successfully signed up.</p>
    <p>Your login credentials are as follows:</p>
    <ul>
        <li><strong>Email:</strong> {{ $email }}</li>
        <li><strong>Password:</strong> {{ $password }}</li>
    </ul>
    <p>We recommend you log in and change your password as soon as possible for enhanced security.</p>
    <p>Thank you for joining us!</p>
</body> --}}
</html>
