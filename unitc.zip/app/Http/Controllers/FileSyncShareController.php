<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FileSyncShareController extends Controller
{
    //
}
